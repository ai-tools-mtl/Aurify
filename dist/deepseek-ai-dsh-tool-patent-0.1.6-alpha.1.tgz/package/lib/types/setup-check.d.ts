/**
 * The host-plane environment self-check: one probe per optional channel of
 * the patent plugin, usable before anything else is configured. This lives
 * on the host side deliberately — an MCP-served check cannot diagnose an MCP
 * row that never loaded, so the one tool that names the missing row must not
 * depend on it. Every probe is best-effort: a broken channel is a report
 * row, never a thrown error.
 * @module dsh-tool-patent/setup-check
 */
/**
 * The optional-settings file (`~/.dsh/patent-services.yaml`), parsed as the
 * flat `key: value` map this plugin writes: comments and blank lines skipped,
 * nested keys left alone. Mirrors python's config.py resolution order — the
 * environment variable still wins — so both planes report one truth.
 * @returns the parsed flat key/value map; empty when the file is absent.
 */
export declare function readSettings(): Map<string, string>;
/**
 * Resolve one option: environment variable first, then the settings file.
 * @param envName - the option's environment variable name.
 * @param fileKey - its settings-file key.
 * @returns the resolved value, or undefined when neither source sets it.
 */
export declare function optionValue(envName: string, fileKey: string): string | undefined;
/**
 * Whether the home-level patch layer (~/.dsh/cordis.patch.yml) carries an
 * enabled mcp-patent-services row — the configuration-file way of enabling
 * the MCP services, replacing setx for people. A text-level check on
 * purpose: the row's shape is ours, and YAML parsing here would import a
 * dependency the tool does not otherwise need.
 * @returns whether an enabled mcp-patent-services row sits in the home patch.
 */
export declare function homePatchEnablesMcp(): boolean;
/** One channel's verdict. */
export interface SetupChannel {
    /** `ok` works, `warn` works with a caveat, `fail` is unusable, `info` is neutral state. */
    status: 'ok' | 'warn' | 'fail' | 'info';
    /** The user-facing verdict line (Chinese), fix included when the status is not `ok`. */
    line: string;
    /** Which capability the channel gates, for the summary line. */
    gates: 'MCP 服务' | '附图渲染与实验' | '附图渲染' | '查新检索' | '';
}
/**
 * Probe every optional channel once. Pure environment reads plus bounded
 * child processes and one network fetch — no project state, no MCP.
 * @returns one verdict per channel, in report order.
 */
export declare function checkSetupChannels(): Promise<SetupChannel[]>;
/**
 * Render the channels as the model- and user-facing report.
 * @param channels - the probed channels.
 * @returns the full Chinese report with the readiness conclusion.
 */
export declare function formatSetupReport(channels: readonly SetupChannel[]): string;
//# sourceMappingURL=setup-check.d.ts.map