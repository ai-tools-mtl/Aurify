/**
 * Model-facing deterministic patent tools: the five-party alignment coverage
 * scorer that gates the Init dialogue, the claims-and-abstract linter for
 * application drafting, and the patent-loop state assessor that drives a
 * project from any stage to the exported disclosure. The coverage and lint
 * tools are pure functions of their arguments; the loop tool and the
 * `/patent-loop` command read project state from disk and share one
 * assessor, so the completion verdict never depends on the model's own
 * claim of being done. Named exports preserve loader injection metadata.
 * @module @deepseek-ai/dsh-tool-patent
 */
import type { Context } from '@deepseek-ai/cordis';
export { computeCoverage } from './coverage.ts';
export type { Coverage, DimensionOutline } from './coverage.ts';
export { lintClaims, parseClaims, countAbstractChars, ABSTRACT_MAX_CHARS } from './claims-lint.ts';
export type { ClaimsLintResult, ParsedClaim, ClaimViolation } from './claims-lint.ts';
export { lintProse } from './prose-lint.ts';
export type { ProseLintResult, ProseViolation } from './prose-lint.ts';
export { assessLoopState } from './loop.ts';
export type { LoopGap, LoopStage, LoopState } from './loop.ts';
export { checkSetupChannels, formatSetupReport } from './setup-check.ts';
export type { SetupChannel } from './setup-check.ts';
export declare const name = "tool-patent";
export declare const inject: string[];
/**
 * Register the `patent_brief_coverage` and `patent_claims_lint` tools, the
 * `patent_loop` assessor tool, and the `/patent-loop` command on `ctx`.
 * @param ctx - registrant context carrying the tool and command registries.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map