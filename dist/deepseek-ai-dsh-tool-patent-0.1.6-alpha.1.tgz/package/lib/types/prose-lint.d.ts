/**
 * Deterministic de-AI prose lint for disclosure chapters: the machine half of
 * the patent-de-ai skill. The skill's six features become five checkable
 * rules — filler phrases, overlong sentences, triple parallelisms,
 * paragraph-ending summaries, and textbook definitions — each a pure function
 * over the submitted text, so "read like a senior patent engineer" stops
 * being a hope and becomes a gate the model must clear. Rhythm (rule 5) is
 * the one feature left to the checklist: no honest regex exists for it.
 * @module dsh-tool-patent/prose-lint
 */
/** One lint finding: what rule tripped, how badly, and where roughly. */
export interface ProseViolation {
    /** The rule key that tripped (stable identifier). */
    rule: 'cliche' | 'long-sentence' | 'parallelism' | 'paragraph-summary' | 'definition';
    /** 'error' rules must be cleared; 'warning' rules are drafting hints. */
    severity: 'error' | 'warning';
    /** What to do about it, in the skill's own terms. */
    message: string;
    /** A short excerpt of the offending text (trimmed around the match). */
    excerpt: string;
}
/** The lint's folded projection: counts by rule plus the violation list. */
export interface ProseLintResult {
    summary: {
        cliches: number;
        longSentences: number;
        parallelisms: number;
        paragraphSummaries: number;
        definitions: number;
        errors: number;
        warnings: number;
    };
    violations: ProseViolation[];
}
/**
 * Lint one chapter (or any prose span) against the de-AI rules.
 * @param text - the prose to check.
 * @returns the folded counts and the violation list (errors first).
 */
export declare function lintProse(text: string): ProseLintResult;
//# sourceMappingURL=prose-lint.d.ts.map