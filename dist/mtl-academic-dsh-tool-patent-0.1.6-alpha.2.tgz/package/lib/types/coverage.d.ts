/**
 * Five-party alignment (五方对齐) coverage scorer for patent disclosure briefs.
 *
 * Ported from TianGong's `app/ai/brief_dimensions.py`, the single authority for
 * Init-stage readiness: which dimensions must be collected, how coverage and
 * alignment are computed, and the readiness threshold. The heuristic point
 * count and the tolerance are ported asset semantics, not deployment tunables.
 * @module
 */
/** Core dimensions: a brief is ready only when every one of them has content. */
export declare const CORE_DIMENSIONS: readonly ["field", "background", "problem", "solution", "effect"];
/** Edge dimensions: displayed for completeness, never gate readiness. */
export declare const EDGE_DIMENSIONS: readonly ["name", "drawings", "key_points"];
/** Every dimension key accepted by the scorer, core first. */
export declare const ALL_DIMENSIONS: readonly ["field", "background", "problem", "solution", "effect", "name", "drawings", "key_points"];
/** Dimension keys whose point counts take part in the alignment check. */
export declare const ALIGNMENT_DIMENSIONS: readonly ["background", "problem", "effect"];
/**
 * Largest allowed spread between the three alignment counts. Init-stage
 * information is coarse, so exact equality is too strict; the ported asset
 * allows e.g. two shortcomings against two problems and one effect.
 */
export declare const ALIGN_TOLERANCE = 1;
/** One collected dimension's draft content. */
export type DimensionOutline = Partial<Record<(typeof ALL_DIMENSIONS)[number], string>>;
/** Coverage result: what is collected, what is missing, and whether the brief is ready. */
export interface Coverage {
    /** Core dimension keys with non-blank content, in core order. */
    covered: string[];
    /** Core dimension keys still missing, in core order. */
    missing: string[];
    /** Every core dimension covered AND the three-way alignment within tolerance. */
    ready: boolean;
    /** Collected core dimensions over the core total. */
    coreFilled: {
        done: number;
        total: number;
    };
    /** Whether the background/problem/effect counts stay within tolerance; true while any of them is uncollected. */
    aligned: boolean;
    /** Point count per alignment dimension, for display and debugging. */
    alignmentCounts: Record<(typeof ALIGNMENT_DIMENSIONS)[number], number>;
}
/**
 * Estimate a dimension's point count for the alignment check: split on
 * enumeration markers and on semicolons/newlines, take the larger count, and
 * count any non-blank content as one point. The estimate is deliberately
 * coarse — alignment only needs the three counts to stay close, not exact.
 * @param text - the dimension's collected content.
 * @returns the estimated point count; 0 for blank content.
 */
export declare function countPoints(text: string | undefined): number;
/**
 * Score a draft brief's five-party alignment coverage.
 * @param outline - collected content per dimension key; absent or blank means uncollected.
 * @returns the coverage result. `ready` requires all five core dimensions
 * covered and the background/problem/effect counts within {@link ALIGN_TOLERANCE};
 * the alignment check passes vacuously while any of the three is uncollected.
 */
export declare function computeCoverage(outline: DimensionOutline): Coverage;
/** Chinese title per dimension key, from TianGong's disclosure chapter structure. */
export declare const DIMENSION_TITLES: Readonly<Record<(typeof ALL_DIMENSIONS)[number], string>>;
//# sourceMappingURL=coverage.d.ts.map