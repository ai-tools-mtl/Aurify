/**
 * The host-plane environment self-check: one probe per optional channel of
 * the patent plugin, usable before anything else is configured. This lives
 * on the host side deliberately — an MCP-served check cannot diagnose an MCP
 * row that never loaded, so the one tool that names the missing row must not
 * depend on it. Every probe is best-effort: a broken channel is a report
 * row, never a thrown error.
 * @module dsh-tool-patent/setup-check
 */
/**
 * The optional-settings file (`~/.dsh/patent-services.yaml`), parsed as the
 * flat `key: value` map this plugin writes: comments and blank lines skipped,
 * nested keys left alone. Mirrors python's config.py resolution order — the
 * environment variable still wins — so both planes report one truth.
 * @returns the parsed flat key/value map; empty when the file is absent.
 */
export declare function readSettings(): Map<string, string>;
/**
 * The first settings-file line carrying a control character, when there is
 * one — the corruption report behind both the reader's line skip and the
 * setup check's dedicated fail row.
 * @returns the human diagnosis naming the line, or null when the file is clean.
 */
export declare function settingsCorruption(): string | null;
/**
 * Resolve one option: environment variable first, then the settings file.
 * @param envName - the option's environment variable name.
 * @param fileKey - its settings-file key.
 * @returns the resolved value, or undefined when neither source sets it.
 */
export declare function optionValue(envName: string, fileKey: string): string | undefined;
/**
 * Whether the home-level patch layer (~/.dsh/cordis.patch.yml) carries an
 * enabled mcp-patent-services row — the configuration-file way of enabling
 * the MCP services, replacing setx for people. A text-level check on
 * purpose: the row's shape is ours, and YAML parsing here would import a
 * dependency the tool does not otherwise need.
 * @returns whether an enabled mcp-patent-services row sits in the home patch.
 */
export declare function homePatchEnablesMcp(): boolean;
/** One launch shape for the patent MCP services, resolved from the settings file. */
export interface McpLaunch {
    /** How the settings file named the backend. */
    mode: 'source' | 'wheel';
    /** The executable `ctx.plugin` spawns. */
    command: string;
    /** Its argv. */
    args: readonly string[];
    /** The source directory when mode is 'source' — the check validates it. */
    projectDir?: string;
}
/** Record that this boot loaded the MCP client from the settings file. */
export declare function markSettingsMcpLoaded(): void;
/**
 * Record that the settings-file MCP load failed this boot. apply() catches
 * the mount error so a broken optional row never takes the host-plane tools
 * down with it; the check turns the cause into a report row instead.
 * @param error - whatever `ctx.plugin(McpClient, …)` rejected with.
 */
export declare function noteSettingsMcpLoadError(error: unknown): void;
/** Whether this boot loaded the MCP client from the settings file.
 * @returns whether apply() ran the settings-file MCP load in this process.
 */
export declare function settingsMcpLoaded(): boolean;
/** Clear the boot marker and load-error cause (test isolation only). */
export declare function resetSettingsMcpLoadedForTests(): void;
/**
 * Resolve the patent MCP services launch from the settings file's flat keys
 * (`mcp_enabled` plus `mcp_project_dir` or `mcp_wheel`) — the single-file way
 * of enabling the services, read by the plugin itself at load time. Callers
 * skip it when the env opt-in or a home-patch row already enabled the static
 * bundle row (a duplicate `serverName` fails loud). Pure resolver: it does
 * not touch the filesystem or PATH — `checkSetupChannels` validates the
 * resolved launch and names whatever is wrong with it.
 * @returns the launch, or null when the file does not enable it.
 */
export declare function mcpFromSettings(): McpLaunch | null;
/**
 * The config-shape problems that make a settings-file launch unspawnable:
 * a relative project dir (uv would resolve it against the dsh process's
 * working directory — the desktop app's install dir, not the user's) or a
 * directory without a pyproject.toml. The loader runs this before spawning
 * so the load-failure state carries a readable cause instead of uv's raw
 * error; the check reuses it for the same messages.
 * @param launch - the resolved settings-file launch.
 * @returns the blocking reason, or null when the launch shape is spawnable.
 */
export declare function launchBlockage(launch: McpLaunch): string | null;
/** One channel's verdict. */
export interface SetupChannel {
    /** `ok` works, `warn` works with a caveat, `fail` is unusable, `info` is neutral state. */
    status: 'ok' | 'warn' | 'fail' | 'info';
    /** The user-facing verdict line (Chinese), fix included when the status is not `ok`. */
    line: string;
    /** Which capability the channel gates, for the summary line. */
    gates: 'MCP 服务' | '附图渲染与实验' | '附图渲染' | '查新检索' | '配置文件' | '';
}
/**
 * Probe every optional channel once. Pure environment reads plus bounded
 * child processes and one network fetch — no project state, no MCP.
 * @returns one verdict per channel, in report order.
 */
export declare function checkSetupChannels(): Promise<SetupChannel[]>;
/**
 * Render the channels as the model- and user-facing report.
 * @param channels - the probed channels.
 * @returns the full Chinese report with the readiness conclusion.
 */
export declare function formatSetupReport(channels: readonly SetupChannel[]): string;
//# sourceMappingURL=setup-check.d.ts.map