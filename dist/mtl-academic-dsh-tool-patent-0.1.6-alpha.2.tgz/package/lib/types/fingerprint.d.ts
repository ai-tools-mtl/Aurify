/**
 * The source-set digest stamped into review reports and export sidecars:
 * a content hash over exactly the file set the loop's freshness gates measure
 * (top-level files of `chapters/` and `figures/`, plus `brief.md`). Unlike
 * mtimes, the digest survives git checkouts and directory syncs — a review is
 * stale exactly when the bytes it reviewed changed, not when something touched
 * the files on the way.
 *
 * Cross-language contract: `python/patent-services/src/patent_services/fingerprint.py`
 * computes the same digest for the export sidecar, and both test suites pin
 * one fixture to one hardcoded digest. Change the algorithm in all three
 * places or not at all.
 * @module dsh-tool-patent/fingerprint
 */
/** Digest length kept in report stamps and sidecars (64 bits of sha256). */
export declare const FINGERPRINT_LENGTH = 16;
/**
 * Compute the source fingerprint for one project directory.
 * @param root - the project directory.
 * @returns the first {@link FINGERPRINT_LENGTH} hex chars of the sha256 over
 * `relPath \0 bytes \0` for every set file in sorted relPath order (relPath
 * uses forward slashes; files missing from the set simply do not contribute).
 */
export declare function sourceFingerprint(root: string): Promise<string>;
//# sourceMappingURL=fingerprint.d.ts.map