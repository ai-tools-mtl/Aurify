/**
 * The fixed patent-review orchestration script, executed by the workflow
 * engine's worker. Host data: the model never supplies or edits this script,
 * which is what makes a review run deterministic in structure — the same
 * input always produces the same set of scoring children, one per rubric
 * dimension per configured pass, folded into per-dimension averages and a
 * weight-renormalized overall score. A failed child resolves to `null` and
 * lowers that dimension's pass count instead of failing the run.
 *
 * When the caller supplies `consistency` (the application's claims and
 * description texts), a second NLI-style phase runs: per pass one
 * claims→description support child and one terminology-consistency child,
 * aggregated into an overall consistency score with the union of
 * unsupported-claim findings. Absent, the phase is skipped and the outcome
 * carries no consistency section.
 * @module
 */
export declare const REVIEW_SCRIPT: string;
//# sourceMappingURL=script.d.ts.map