import type { ReactNode } from 'react';
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ProjectView } from './project-model.ts';
type PatentBodyProps = PropsRuntime<'sidebar.right.pane.tab'> & PropsLocale<'patent'>;
/**
 * Render the project overview: presence of the five-party artifacts, the eight
 * chapters' draft state, the review reports, and the figure sources. All data
 * comes from the session workspace through the injected face.
 * @param props - tab slot props plus the patent locale seat.
 * @returns the overview, or the not-a-project hint.
 */
export declare function ProjectOverview({ view, t }: {
    view: ProjectView;
    t: PatentBodyProps['t'];
}): ReactNode;
export {};
//# sourceMappingURL=ProjectOverview.d.ts.map