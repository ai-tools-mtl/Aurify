/**
 * The dashboard's asynchronous body: performs the workspace listings for the
 * open session's project directory, derives the overview, and offers a manual
 * refresh. All state is component-local; the session id arrives as a standard
 * slot prop (the tab slot is session-scoped).
 * @module
 */
import { type ReactNode } from 'react';
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { PatentProjectInjected } from './patent-face.ts';
type PatentBodyProps = PropsRuntime<'sidebar.right.pane.tab'> & PropsLocale<'patent'> & PatentProjectInjected;
/**
 * Render the project overview for the open session's workspace.
 * @param props - tab slot props (sessionId included), the injected face, and copy.
 * @returns the dashboard body.
 */
export declare function PatentBody({ listDirectory, readProjectFile, t }: PatentBodyProps): ReactNode;
export {};
//# sourceMappingURL=PatentBody.d.ts.map