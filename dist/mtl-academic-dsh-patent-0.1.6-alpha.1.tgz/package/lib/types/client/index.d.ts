/**
 * Patent bundle browser half: the two deterministic patent tools render as
 * structured cards (readiness chips, violation list) instead of generic text
 * rows, and a right-sidebar tab lists the open workspace's project overview.
 * Card bodies derive from the persisted presentation meta with a render-text
 * fallback, so live and replay renders stay identical.
 * @module @mtl-academic/dsh-patent/client
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
/** Required services: the slot and locale registries, the right-sidebar tab registry, and the workspace-files Remote. */
export declare const inject: string[];
/**
 * Register the two keyed tool views, the dictionaries, and the project
 * dashboard tab.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map