import type { ToolCallViewProps } from '@deepseek-ai/dsh-client-ui-tool/client';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
type CoverageCardProps = ToolCallViewProps & PropsLocale<'patent'>;
/**
 * Render one `patent_brief_coverage` call as a readiness card: five dimension
 * chips, the three-way point counts, and the verdict. Settled cards prefer the
 * persisted presentation meta; sessions logged without it fall back to the
 * rendered text inside a disclosure.
 * @param props - keyed toolview payload plus the patent locale seat.
 * @returns the coverage card.
 */
export declare function CoverageCard({ block, t }: CoverageCardProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=CoverageCard.d.ts.map