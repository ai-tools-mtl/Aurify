import type { ToolCallViewProps } from '@deepseek-ai/dsh-client-ui-tool/client';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
type ReviewCardProps = ToolCallViewProps & PropsLocale<'patent'>;
/**
 * Render one `patent_review` call as a rubric card: the overall score, one
 * bar per rubric dimension (with failed-pass markers), and the report path.
 * Settled cards prefer the persisted presentation meta; sessions logged
 * without it fall back to the summary text inside a disclosure.
 * @param props - keyed toolview payload plus the patent locale seat.
 * @returns the review card.
 */
export declare function ReviewCard({ block, t }: ReviewCardProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=ReviewCard.d.ts.map